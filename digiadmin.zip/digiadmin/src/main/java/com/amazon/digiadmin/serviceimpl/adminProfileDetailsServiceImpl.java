package com.amazon.digiadmin.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amazon.digiadmin.dao.AdminProfileDetailsRepository;

import com.amazon.digiadmin.entity.AdminProfileDetailsEntity;
import com.amazon.digiadmin.service.AdminProfileDetailsService;

@Component
public class adminProfileDetailsServiceImpl  implements AdminProfileDetailsService{

            
    @Autowired
    private AdminProfileDetailsRepository adminProfileDetailsRepository;

	@Override
	public void saveadminProfileDetails(AdminProfileDetailsEntity adminProfileDetails) {
		adminProfileDetailsRepository.save(adminProfileDetails);
		
		
	}

	           


}
