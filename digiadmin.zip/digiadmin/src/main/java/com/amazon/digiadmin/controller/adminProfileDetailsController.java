package com.amazon.digiadmin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amazon.digiadmin.dto.ApiResponse;
import com.amazon.digiadmin.entity.AdminProfileDetailsEntity;
import com.amazon.digiadmin.service.AdminProfileDetailsService;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@RequestMapping("/adminprofile")
public class adminProfileDetailsController {
	
	@Autowired
	private AdminProfileDetailsService adminProfileDetailsService;

	@PostMapping("/save-adminProfile")
	public ResponseEntity<ApiResponse<AdminProfileDetailsEntity>> saveRoleData(
			@RequestBody AdminProfileDetailsEntity adminProfileDetails) {
		adminProfileDetailsService.saveadminProfileDetails(adminProfileDetails);
		ApiResponse<AdminProfileDetailsEntity> response = ApiResponse.success("Admin Profile Details Saved Successfully");
		return ResponseEntity.ok(response);
	}


}
