package com.amazon.digiadmin.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "adminprofiledetails")
@Data

public class AdminProfileDetailsEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	private String address;
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern = "dd-mm-yyyy")
	private String dob ;
	private String emailId;
	private String gender;
	private long mobileNo;
	
	

}
