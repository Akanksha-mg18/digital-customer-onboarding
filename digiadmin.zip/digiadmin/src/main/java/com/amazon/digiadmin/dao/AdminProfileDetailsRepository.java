package com.amazon.digiadmin.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.amazon.digiadmin.entity.AdminProfileDetailsEntity;


@Repository
public interface AdminProfileDetailsRepository extends JpaRepository<AdminProfileDetailsEntity, Long> {
	
			@Query(value="select ap.address,ap.emailid,ap.gender"+" from admin_profile_details ap",nativeQuery = true)
		public List<Object[]> getAdminProfileDetailsData();


}

