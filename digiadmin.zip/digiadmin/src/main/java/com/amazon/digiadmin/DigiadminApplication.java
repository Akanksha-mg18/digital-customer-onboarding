package com.amazon.digiadmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigiadminApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigiadminApplication.class, args);
		System.out.println("*****Application Start*****");
	}

}
