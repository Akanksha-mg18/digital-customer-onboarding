package com.amazon.digiadmin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.amazon.digiadmin.entity.AdminProfileDetailsEntity;

@Service
public interface AdminProfileDetailsService {
	
	public void saveadminProfileDetails(AdminProfileDetailsEntity adminProfileDetails);

	/*public List<adminProfileDetailsService> getAdminProfileDetailsData();

	public adminProfileDetailsService getAdminProfileById(long id);

	public void updateAdminProfileDetails(adminProfileDetailsService adminProfileDetailsEntity);

	public void deleteAdminProfileData(long id);
	
	public List<adminProfileDetailsService>getAdminProfileData();*/

}
